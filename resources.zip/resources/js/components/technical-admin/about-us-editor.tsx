import { router } from '@inertiajs/react';
import { Check, Info, RotateCcw } from 'lucide-react';
import { useState } from 'react';
import { Field, GoldButton, OutlineButton, Panel, PanelHeader, inputClass, textareaClass } from '@/components/dashboard/ui';
import { cn } from '@/lib/utils';



const LIMITS = { title: 40, content: 1500 };

const ABOUT_URL = '/technical-admin/website-content/about';

export type AboutUs = { title: string; content: string };

const toParagraphs = (text: string) =>
    text
        .split(/\n\s*\n/)
        .map((p) => p.trim())
        .filter(Boolean);

export default function AboutUsEditor({ about: initial }: { about: AboutUs }) {
    const [saved, setSaved] = useState<AboutUs>(initial);
    const [about, setAbout] = useState<AboutUs>(initial);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [message, setMessage] = useState('');
    const [saving, setSaving] = useState(false);

    const dirty = JSON.stringify(about) !== JSON.stringify(saved);
    const paragraphs = toParagraphs(about.content);

    const change = (changes: Partial<AboutUs>) => {
        setAbout({ ...about, ...changes });
        setMessage('');
    };

    const save = () => {
        const e: Record<string, string> = {};
        if (!about.title.trim()) e.title = 'Section title is required.';
        if (!about.content.trim()) e.content = 'Content is required.';
        setErrors(e);
        if (Object.keys(e).length) return;

        router.put(ABOUT_URL, about, {
            preserveScroll: true,
            preserveState: true,
            onStart: () => setSaving(true),
            onFinish: () => setSaving(false),
            onSuccess: () => {
                setSaved(about);
                setMessage('Changes saved');
            },
            onError: (serverErrors) => setErrors(serverErrors),
        });
    };

    const reset = () => {
        setAbout(saved);
        setErrors({});
        setMessage('');
    };

    return (
        <div className="space-y-5">
            <div className="grid gap-5">
                {/* Form */}
                <Panel>
                    <PanelHeader
                        title="About Us Content"
                        description="Introduce the company below the hero section"
                        icon={<Info className="size-5" />}
                    />

                    <div className="space-y-4">
                        <Field label="Section title" htmlFor="about-title" required error={errors.title}>
                            <input
                                id="about-title"
                                className={inputClass}
                                maxLength={LIMITS.title}
                                value={about.title}
                                onChange={(e) => change({ title: e.target.value })}
                            />
                            <span className="text-right text-[11px] text-ink-soft">
                                {about.title.length}/{LIMITS.title}
                            </span>
                        </Field>

                        <Field label="Content" htmlFor="about-content" required error={errors.content}>
                            <textarea
                                id="about-content"
                                className={cn(textareaClass, 'field-sizing-content')}
                                rows={10}
                                style={{ minHeight: 'clamp(14rem, 45vh, 32rem)' }}
                                maxLength={LIMITS.content}
                                value={about.content}
                                onChange={(e) => change({ content: e.target.value })}
                            />
                            <div className="flex items-center justify-between text-[11px] text-ink-soft">
                                <span>Leave a blank line between paragraphs.</span>
                                <span>
                                    {about.content.length}/{LIMITS.content}
                                </span>
                            </div>
                        </Field>
                    </div>
                </Panel>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3">
                {message && <span className="text-xs font-semibold text-green-700">{message}</span>}
                {dirty && !message && <span className="text-xs text-ink-soft">You have unsaved changes</span>}
                <OutlineButton onClick={reset} disabled={!dirty}>
                    <RotateCcw className="size-4" /> Reset
                </OutlineButton>
                <GoldButton onClick={save} disabled={!dirty || saving}>
                    <Check className="size-4" /> Save Changes
                </GoldButton>
            </div>
        </div>
    );
}

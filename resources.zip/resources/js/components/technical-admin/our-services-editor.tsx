import { router } from '@inertiajs/react';
import { Check, Layers, RotateCcw } from 'lucide-react';
import { useState } from 'react';
import { Field, GoldButton, OutlineButton, Panel, PanelHeader, inputClass, textareaClass } from '@/components/dashboard/ui';
import { cn } from '@/lib/utils';


const LIMITS = { title: 40, intro: 200, cardTitle: 40, cardText: 150 };

type Card = { title: string; description: string };
export type OurServices = { title: string; intro: string; cards: Card[] };

const SERVICES_URL = '/technical-admin/website-content/services';

function Counter({ value, max }: { value: string; max: number }) {
    return (
        <span className="text-right text-[11px] text-ink-soft">
            {value.length}/{max}
        </span>
    );
}

export default function OurServicesEditor({ services }: { services: OurServices }) {
    const [saved, setSaved] = useState<OurServices>(services);
    const [data, setData] = useState<OurServices>(services);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [message, setMessage] = useState('');
    const [saving, setSaving] = useState(false);

    const dirty = JSON.stringify(data) !== JSON.stringify(saved);

    const change = (next: OurServices) => {
        setData(next);
        setMessage('');
    };

    const setCard = (index: number, changes: Partial<Card>) =>
        change({ ...data, cards: data.cards.map((c, i) => (i === index ? { ...c, ...changes } : c)) });

    const save = () => {
        const e: Record<string, string> = {};
        if (!data.title.trim()) e.title = 'Section title is required.';
        data.cards.forEach((c, i) => {
            if (!c.title.trim()) e[`title-${i}`] = 'Card title is required.';
            if (!c.description.trim()) e[`description-${i}`] = 'Card description is required.';
        });
        setErrors(e);
        if (Object.keys(e).length) return;

        router.put(SERVICES_URL, data, {
            preserveScroll: true,
            preserveState: true,
            onStart: () => setSaving(true),
            onFinish: () => setSaving(false),
            onSuccess: () => {
                setSaved(data);
                setMessage('Changes saved');
            },
            onError: (serverErrors) => {
                // cards.1.title -> title-1, the keys this form uses
                const mapped: Record<string, string> = {};
                Object.entries(serverErrors).forEach(([key, text]) => {
                    const card = key.match(/^cards\.(\d+)\.(title|description)$/);
                    mapped[card ? `${card[2]}-${card[1]}` : key] = text;
                });
                setErrors(mapped);
            },
        });
    };

    const reset = () => {
        setData(saved);
        setErrors({});
        setMessage('');
    };

    return (
        <div className="space-y-5">
            <div>
                {/* Form */}
                <div className="space-y-5">
                    <Panel>
                        <PanelHeader
                            title="Section Heading"
                            description="The title shown above the service cards"
                            icon={<Layers className="size-5" />}
                        />
                        <div className="space-y-4">
                            <Field label="Section title" htmlFor="svc-title" required error={errors.title}>
                                <input
                                    id="svc-title"
                                    className={inputClass}
                                    maxLength={LIMITS.title}
                                    value={data.title}
                                    onChange={(e) => change({ ...data, title: e.target.value })}
                                />
                                <Counter value={data.title} max={LIMITS.title} />
                            </Field>
                            <Field label="Intro line (optional)" htmlFor="svc-intro">
                                <input
                                    id="svc-intro"
                                    className={inputClass}
                                    maxLength={LIMITS.intro}
                                    value={data.intro}
                                    onChange={(e) => change({ ...data, intro: e.target.value })}
                                />
                                <Counter value={data.intro} max={LIMITS.intro} />
                            </Field>
                        </div>
                    </Panel>

                    <div className="grid gap-5 lg:grid-cols-3">
                    {data.cards.map((card, i) => (
                        <Panel key={i}>
                            <div className="mb-4 flex items-center gap-3">
                                <span className="flex size-7 items-center justify-center rounded-full bg-gold text-xs font-bold text-white">
                                    {i + 1}
                                </span>
                                <h2 className="text-base font-bold text-ink">Card {i + 1}</h2>
                            </div>
                            <div className="space-y-4">
                                <Field label="Title" htmlFor={`card-title-${i}`} required error={errors[`title-${i}`]}>
                                    <input
                                        id={`card-title-${i}`}
                                        className={inputClass}
                                        maxLength={LIMITS.cardTitle}
                                        value={card.title}
                                        onChange={(e) => setCard(i, { title: e.target.value })}
                                    />
                                    <Counter value={card.title} max={LIMITS.cardTitle} />
                                </Field>
                                <Field label="Description" htmlFor={`card-text-${i}`} required error={errors[`description-${i}`]}>
                                    <textarea
                                        id={`card-text-${i}`}
                                        className={cn(textareaClass, 'min-h-28')}
                                        maxLength={LIMITS.cardText}
                                        value={card.description}
                                        onChange={(e) => setCard(i, { description: e.target.value })}
                                    />
                                    <Counter value={card.description} max={LIMITS.cardText} />
                                </Field>
                            </div>
                        </Panel>
                    ))}
                    </div>
                </div>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3">
                {message && <span className="text-xs font-semibold text-green-700">{message}</span>}
                {dirty && !message && <span className="text-xs text-ink-soft">You have unsaved changes</span>}
                <OutlineButton onClick={reset} disabled={!dirty}>
                    <RotateCcw className="size-4" /> Reset
                </OutlineButton>
                <GoldButton onClick={save} disabled={!dirty || saving}>
                    <Check className="size-4" /> Save Changes
                </GoldButton>
            </div>
        </div>
    );
}

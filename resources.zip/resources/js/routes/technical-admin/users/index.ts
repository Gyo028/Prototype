import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::store
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:61
 * @route '/technical-admin/users'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/technical-admin/users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::store
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:61
 * @route '/technical-admin/users'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::store
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:61
 * @route '/technical-admin/users'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::store
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:61
 * @route '/technical-admin/users'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::store
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:61
 * @route '/technical-admin/users'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::update
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:83
 * @route '/technical-admin/users/{user}'
 */
export const update = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/technical-admin/users/{user}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::update
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:83
 * @route '/technical-admin/users/{user}'
 */
update.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return update.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::update
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:83
 * @route '/technical-admin/users/{user}'
 */
update.patch = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::update
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:83
 * @route '/technical-admin/users/{user}'
 */
    const updateForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::update
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:83
 * @route '/technical-admin/users/{user}'
 */
        updateForm.patch = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::archive
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:97
 * @route '/technical-admin/users/{user}/archive'
 */
export const archive = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

archive.definition = {
    methods: ["patch"],
    url: '/technical-admin/users/{user}/archive',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::archive
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:97
 * @route '/technical-admin/users/{user}/archive'
 */
archive.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return archive.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::archive
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:97
 * @route '/technical-admin/users/{user}/archive'
 */
archive.patch = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::archive
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:97
 * @route '/technical-admin/users/{user}/archive'
 */
    const archiveForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::archive
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:97
 * @route '/technical-admin/users/{user}/archive'
 */
        archiveForm.patch = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::restore
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:112
 * @route '/technical-admin/users/{user}/restore'
 */
export const restore = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

restore.definition = {
    methods: ["patch"],
    url: '/technical-admin/users/{user}/restore',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::restore
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:112
 * @route '/technical-admin/users/{user}/restore'
 */
restore.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return restore.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::restore
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:112
 * @route '/technical-admin/users/{user}/restore'
 */
restore.patch = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::restore
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:112
 * @route '/technical-admin/users/{user}/restore'
 */
    const restoreForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::restore
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:112
 * @route '/technical-admin/users/{user}/restore'
 */
        restoreForm.patch = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    restore.form = restoreForm
const users = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
archive: Object.assign(archive, archive),
restore: Object.assign(restore, restore),
}

export default users
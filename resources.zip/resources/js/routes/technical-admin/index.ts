import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import users48860f from './users'
import websiteContent8462cb from './website-content'
import servicesAssetsF6c60e from './services-assets'
import employeesF5c829 from './employees'
/**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::dashboard
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/technical-admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::dashboard
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::dashboard
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::dashboard
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::dashboard
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::dashboard
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::dashboard
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::users
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:35
 * @route '/technical-admin/users'
 */
export const users = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})

users.definition = {
    methods: ["get","head"],
    url: '/technical-admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::users
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:35
 * @route '/technical-admin/users'
 */
users.url = (options?: RouteQueryOptions) => {
    return users.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::users
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:35
 * @route '/technical-admin/users'
 */
users.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::users
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:35
 * @route '/technical-admin/users'
 */
users.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: users.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::users
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:35
 * @route '/technical-admin/users'
 */
    const usersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: users.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::users
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:35
 * @route '/technical-admin/users'
 */
        usersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TechnicalAdmin\UserAccountController::users
 * @see app/Http/Controllers/TechnicalAdmin/UserAccountController.php:35
 * @route '/technical-admin/users'
 */
        usersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    users.form = usersForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::websiteContent
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
export const websiteContent = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: websiteContent.url(options),
    method: 'get',
})

websiteContent.definition = {
    methods: ["get","head"],
    url: '/technical-admin/website-content',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::websiteContent
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
websiteContent.url = (options?: RouteQueryOptions) => {
    return websiteContent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::websiteContent
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
websiteContent.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: websiteContent.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::websiteContent
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
websiteContent.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: websiteContent.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::websiteContent
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
    const websiteContentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: websiteContent.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::websiteContent
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
        websiteContentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: websiteContent.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::websiteContent
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
        websiteContentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: websiteContent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    websiteContent.form = websiteContentForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::servicesAssets
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
export const servicesAssets = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: servicesAssets.url(options),
    method: 'get',
})

servicesAssets.definition = {
    methods: ["get","head"],
    url: '/technical-admin/services-assets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::servicesAssets
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
servicesAssets.url = (options?: RouteQueryOptions) => {
    return servicesAssets.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::servicesAssets
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
servicesAssets.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: servicesAssets.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::servicesAssets
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
servicesAssets.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: servicesAssets.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::servicesAssets
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
    const servicesAssetsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: servicesAssets.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::servicesAssets
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
        servicesAssetsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: servicesAssets.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::servicesAssets
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
        servicesAssetsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: servicesAssets.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    servicesAssets.form = servicesAssetsForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\EmployeeController::employees
 * @see app/Http/Controllers/TechnicalAdmin/EmployeeController.php:31
 * @route '/technical-admin/employees'
 */
export const employees = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employees.url(options),
    method: 'get',
})

employees.definition = {
    methods: ["get","head"],
    url: '/technical-admin/employees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\EmployeeController::employees
 * @see app/Http/Controllers/TechnicalAdmin/EmployeeController.php:31
 * @route '/technical-admin/employees'
 */
employees.url = (options?: RouteQueryOptions) => {
    return employees.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\EmployeeController::employees
 * @see app/Http/Controllers/TechnicalAdmin/EmployeeController.php:31
 * @route '/technical-admin/employees'
 */
employees.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employees.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TechnicalAdmin\EmployeeController::employees
 * @see app/Http/Controllers/TechnicalAdmin/EmployeeController.php:31
 * @route '/technical-admin/employees'
 */
employees.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: employees.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\EmployeeController::employees
 * @see app/Http/Controllers/TechnicalAdmin/EmployeeController.php:31
 * @route '/technical-admin/employees'
 */
    const employeesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: employees.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\EmployeeController::employees
 * @see app/Http/Controllers/TechnicalAdmin/EmployeeController.php:31
 * @route '/technical-admin/employees'
 */
        employeesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employees.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TechnicalAdmin\EmployeeController::employees
 * @see app/Http/Controllers/TechnicalAdmin/EmployeeController.php:31
 * @route '/technical-admin/employees'
 */
        employeesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employees.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    employees.form = employeesForm
const technicalAdmin = {
    dashboard: Object.assign(dashboard, dashboard),
users: Object.assign(users, users48860f),
websiteContent: Object.assign(websiteContent, websiteContent8462cb),
servicesAssets: Object.assign(servicesAssets, servicesAssetsF6c60e),
employees: Object.assign(employees, employeesF5c829),
}

export default technicalAdmin
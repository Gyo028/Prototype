import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::store
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:20
 * @route '/technical-admin/services-assets/services'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/technical-admin/services-assets/services',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::store
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:20
 * @route '/technical-admin/services-assets/services'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::store
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:20
 * @route '/technical-admin/services-assets/services'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::store
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:20
 * @route '/technical-admin/services-assets/services'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::store
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:20
 * @route '/technical-admin/services-assets/services'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::update
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:27
 * @route '/technical-admin/services-assets/services/{service}'
 */
export const update = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/technical-admin/services-assets/services/{service}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::update
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:27
 * @route '/technical-admin/services-assets/services/{service}'
 */
update.url = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'service_id' in args) {
            args = { service: args.service_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    service: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        service: typeof args.service === 'object'
                ? args.service.service_id
                : args.service,
                }

    return update.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::update
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:27
 * @route '/technical-admin/services-assets/services/{service}'
 */
update.patch = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::update
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:27
 * @route '/technical-admin/services-assets/services/{service}'
 */
    const updateForm = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::update
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:27
 * @route '/technical-admin/services-assets/services/{service}'
 */
        updateForm.patch = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::status
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:43
 * @route '/technical-admin/services-assets/services/{service}/status'
 */
export const status = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/technical-admin/services-assets/services/{service}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::status
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:43
 * @route '/technical-admin/services-assets/services/{service}/status'
 */
status.url = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'service_id' in args) {
            args = { service: args.service_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    service: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        service: typeof args.service === 'object'
                ? args.service.service_id
                : args.service,
                }

    return status.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::status
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:43
 * @route '/technical-admin/services-assets/services/{service}/status'
 */
status.patch = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::status
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:43
 * @route '/technical-admin/services-assets/services/{service}/status'
 */
    const statusForm = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\ServiceController::status
 * @see app/Http/Controllers/TechnicalAdmin/ServiceController.php:43
 * @route '/technical-admin/services-assets/services/{service}/status'
 */
        statusForm.patch = (args: { service: number | { service_id: number } } | [service: number | { service_id: number } ] | number | { service_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const services = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
status: Object.assign(status, status),
}

export default services
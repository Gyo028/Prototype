import services from './services'
import themes from './themes'
import assets from './assets'
const servicesAssets = {
    services: Object.assign(services, services),
themes: Object.assign(themes, themes),
assets: Object.assign(assets, assets),
}

export default servicesAssets
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import faqs from './faqs'
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::about
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
export const about = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: about.url(options),
    method: 'put',
})

about.definition = {
    methods: ["put"],
    url: '/technical-admin/website-content/about',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::about
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
about.url = (options?: RouteQueryOptions) => {
    return about.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::about
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
about.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: about.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::about
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
    const aboutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: about.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::about
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
        aboutForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: about.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    about.form = aboutForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::services
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
export const services = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: services.url(options),
    method: 'put',
})

services.definition = {
    methods: ["put"],
    url: '/technical-admin/website-content/services',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::services
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
services.url = (options?: RouteQueryOptions) => {
    return services.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::services
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
services.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: services.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::services
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
    const servicesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: services.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::services
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
        servicesForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: services.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    services.form = servicesForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::contact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
export const contact = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: contact.url(options),
    method: 'put',
})

contact.definition = {
    methods: ["put"],
    url: '/technical-admin/website-content/contact',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::contact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
contact.url = (options?: RouteQueryOptions) => {
    return contact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::contact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
contact.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: contact.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::contact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
    const contactForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: contact.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::contact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
        contactForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: contact.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    contact.form = contactForm
const websiteContent = {
    about: Object.assign(about, about),
services: Object.assign(services, services),
contact: Object.assign(contact, contact),
faqs: Object.assign(faqs, faqs),
}

export default websiteContent
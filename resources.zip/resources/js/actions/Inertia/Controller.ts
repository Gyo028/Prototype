import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
const Controller980bb49ee7ae63891f1d891d2fbcf1c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

Controller980bb49ee7ae63891f1d891d2fbcf1c9.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.url = (options?: RouteQueryOptions) => {
    return Controller980bb49ee7ae63891f1d891d2fbcf1c9.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
    const Controller980bb49ee7ae63891f1d891d2fbcf1c9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        Controller980bb49ee7ae63891f1d891d2fbcf1c9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        Controller980bb49ee7ae63891f1d891d2fbcf1c9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller980bb49ee7ae63891f1d891d2fbcf1c9.form = Controller980bb49ee7ae63891f1d891d2fbcf1c9Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/faq'
 */
const Controller92f1f176050b935721bc0098427f55ed = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller92f1f176050b935721bc0098427f55ed.url(options),
    method: 'get',
})

Controller92f1f176050b935721bc0098427f55ed.definition = {
    methods: ["get","head"],
    url: '/faq',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/faq'
 */
Controller92f1f176050b935721bc0098427f55ed.url = (options?: RouteQueryOptions) => {
    return Controller92f1f176050b935721bc0098427f55ed.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/faq'
 */
Controller92f1f176050b935721bc0098427f55ed.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller92f1f176050b935721bc0098427f55ed.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/faq'
 */
Controller92f1f176050b935721bc0098427f55ed.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller92f1f176050b935721bc0098427f55ed.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/faq'
 */
    const Controller92f1f176050b935721bc0098427f55edForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller92f1f176050b935721bc0098427f55ed.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/faq'
 */
        Controller92f1f176050b935721bc0098427f55edForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller92f1f176050b935721bc0098427f55ed.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/faq'
 */
        Controller92f1f176050b935721bc0098427f55edForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller92f1f176050b935721bc0098427f55ed.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller92f1f176050b935721bc0098427f55ed.form = Controller92f1f176050b935721bc0098427f55edForm
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/our-works'
 */
const Controller406184d23d716dbd5b3cb1b53a2c1750 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller406184d23d716dbd5b3cb1b53a2c1750.url(options),
    method: 'get',
})

Controller406184d23d716dbd5b3cb1b53a2c1750.definition = {
    methods: ["get","head"],
    url: '/our-works',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/our-works'
 */
Controller406184d23d716dbd5b3cb1b53a2c1750.url = (options?: RouteQueryOptions) => {
    return Controller406184d23d716dbd5b3cb1b53a2c1750.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/our-works'
 */
Controller406184d23d716dbd5b3cb1b53a2c1750.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller406184d23d716dbd5b3cb1b53a2c1750.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/our-works'
 */
Controller406184d23d716dbd5b3cb1b53a2c1750.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller406184d23d716dbd5b3cb1b53a2c1750.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/our-works'
 */
    const Controller406184d23d716dbd5b3cb1b53a2c1750Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller406184d23d716dbd5b3cb1b53a2c1750.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/our-works'
 */
        Controller406184d23d716dbd5b3cb1b53a2c1750Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller406184d23d716dbd5b3cb1b53a2c1750.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/our-works'
 */
        Controller406184d23d716dbd5b3cb1b53a2c1750Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller406184d23d716dbd5b3cb1b53a2c1750.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller406184d23d716dbd5b3cb1b53a2c1750.form = Controller406184d23d716dbd5b3cb1b53a2c1750Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer'
 */
const Controller6e8d88c1af9fa55d5456ce0119408fe8 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller6e8d88c1af9fa55d5456ce0119408fe8.url(options),
    method: 'get',
})

Controller6e8d88c1af9fa55d5456ce0119408fe8.definition = {
    methods: ["get","head"],
    url: '/customer',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer'
 */
Controller6e8d88c1af9fa55d5456ce0119408fe8.url = (options?: RouteQueryOptions) => {
    return Controller6e8d88c1af9fa55d5456ce0119408fe8.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer'
 */
Controller6e8d88c1af9fa55d5456ce0119408fe8.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller6e8d88c1af9fa55d5456ce0119408fe8.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer'
 */
Controller6e8d88c1af9fa55d5456ce0119408fe8.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller6e8d88c1af9fa55d5456ce0119408fe8.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer'
 */
    const Controller6e8d88c1af9fa55d5456ce0119408fe8Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller6e8d88c1af9fa55d5456ce0119408fe8.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer'
 */
        Controller6e8d88c1af9fa55d5456ce0119408fe8Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller6e8d88c1af9fa55d5456ce0119408fe8.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer'
 */
        Controller6e8d88c1af9fa55d5456ce0119408fe8Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller6e8d88c1af9fa55d5456ce0119408fe8.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller6e8d88c1af9fa55d5456ce0119408fe8.form = Controller6e8d88c1af9fa55d5456ce0119408fe8Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer/new-request'
 */
const Controller997f8db8c1bc3eba6fdd0516c501f101 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller997f8db8c1bc3eba6fdd0516c501f101.url(options),
    method: 'get',
})

Controller997f8db8c1bc3eba6fdd0516c501f101.definition = {
    methods: ["get","head"],
    url: '/customer/new-request',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer/new-request'
 */
Controller997f8db8c1bc3eba6fdd0516c501f101.url = (options?: RouteQueryOptions) => {
    return Controller997f8db8c1bc3eba6fdd0516c501f101.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer/new-request'
 */
Controller997f8db8c1bc3eba6fdd0516c501f101.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller997f8db8c1bc3eba6fdd0516c501f101.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer/new-request'
 */
Controller997f8db8c1bc3eba6fdd0516c501f101.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller997f8db8c1bc3eba6fdd0516c501f101.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer/new-request'
 */
    const Controller997f8db8c1bc3eba6fdd0516c501f101Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller997f8db8c1bc3eba6fdd0516c501f101.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer/new-request'
 */
        Controller997f8db8c1bc3eba6fdd0516c501f101Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller997f8db8c1bc3eba6fdd0516c501f101.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/customer/new-request'
 */
        Controller997f8db8c1bc3eba6fdd0516c501f101Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller997f8db8c1bc3eba6fdd0516c501f101.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller997f8db8c1bc3eba6fdd0516c501f101.form = Controller997f8db8c1bc3eba6fdd0516c501f101Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/project-manager'
 */
const Controllere5baf0ddea6429d5ed2876261de06f49 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllere5baf0ddea6429d5ed2876261de06f49.url(options),
    method: 'get',
})

Controllere5baf0ddea6429d5ed2876261de06f49.definition = {
    methods: ["get","head"],
    url: '/project-manager',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/project-manager'
 */
Controllere5baf0ddea6429d5ed2876261de06f49.url = (options?: RouteQueryOptions) => {
    return Controllere5baf0ddea6429d5ed2876261de06f49.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/project-manager'
 */
Controllere5baf0ddea6429d5ed2876261de06f49.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllere5baf0ddea6429d5ed2876261de06f49.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/project-manager'
 */
Controllere5baf0ddea6429d5ed2876261de06f49.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllere5baf0ddea6429d5ed2876261de06f49.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/project-manager'
 */
    const Controllere5baf0ddea6429d5ed2876261de06f49Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controllere5baf0ddea6429d5ed2876261de06f49.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/project-manager'
 */
        Controllere5baf0ddea6429d5ed2876261de06f49Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllere5baf0ddea6429d5ed2876261de06f49.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/project-manager'
 */
        Controllere5baf0ddea6429d5ed2876261de06f49Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllere5baf0ddea6429d5ed2876261de06f49.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controllere5baf0ddea6429d5ed2876261de06f49.form = Controllere5baf0ddea6429d5ed2876261de06f49Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/design-specialist'
 */
const Controllera06a54fbf6b5e2042f5d214c429e5006 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllera06a54fbf6b5e2042f5d214c429e5006.url(options),
    method: 'get',
})

Controllera06a54fbf6b5e2042f5d214c429e5006.definition = {
    methods: ["get","head"],
    url: '/design-specialist',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/design-specialist'
 */
Controllera06a54fbf6b5e2042f5d214c429e5006.url = (options?: RouteQueryOptions) => {
    return Controllera06a54fbf6b5e2042f5d214c429e5006.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/design-specialist'
 */
Controllera06a54fbf6b5e2042f5d214c429e5006.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllera06a54fbf6b5e2042f5d214c429e5006.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/design-specialist'
 */
Controllera06a54fbf6b5e2042f5d214c429e5006.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllera06a54fbf6b5e2042f5d214c429e5006.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/design-specialist'
 */
    const Controllera06a54fbf6b5e2042f5d214c429e5006Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controllera06a54fbf6b5e2042f5d214c429e5006.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/design-specialist'
 */
        Controllera06a54fbf6b5e2042f5d214c429e5006Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllera06a54fbf6b5e2042f5d214c429e5006.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/design-specialist'
 */
        Controllera06a54fbf6b5e2042f5d214c429e5006Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllera06a54fbf6b5e2042f5d214c429e5006.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controllera06a54fbf6b5e2042f5d214c429e5006.form = Controllera06a54fbf6b5e2042f5d214c429e5006Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/owner'
 */
const Controllercad30db1f60378b5d578214a41b1c51b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllercad30db1f60378b5d578214a41b1c51b.url(options),
    method: 'get',
})

Controllercad30db1f60378b5d578214a41b1c51b.definition = {
    methods: ["get","head"],
    url: '/owner',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/owner'
 */
Controllercad30db1f60378b5d578214a41b1c51b.url = (options?: RouteQueryOptions) => {
    return Controllercad30db1f60378b5d578214a41b1c51b.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/owner'
 */
Controllercad30db1f60378b5d578214a41b1c51b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllercad30db1f60378b5d578214a41b1c51b.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/owner'
 */
Controllercad30db1f60378b5d578214a41b1c51b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllercad30db1f60378b5d578214a41b1c51b.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/owner'
 */
    const Controllercad30db1f60378b5d578214a41b1c51bForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controllercad30db1f60378b5d578214a41b1c51b.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/owner'
 */
        Controllercad30db1f60378b5d578214a41b1c51bForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllercad30db1f60378b5d578214a41b1c51b.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/owner'
 */
        Controllercad30db1f60378b5d578214a41b1c51bForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllercad30db1f60378b5d578214a41b1c51b.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controllercad30db1f60378b5d578214a41b1c51b.form = Controllercad30db1f60378b5d578214a41b1c51bForm
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/bookkeeper'
 */
const Controller7d9ae9a97553f90b5982151f34a5f9d6 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller7d9ae9a97553f90b5982151f34a5f9d6.url(options),
    method: 'get',
})

Controller7d9ae9a97553f90b5982151f34a5f9d6.definition = {
    methods: ["get","head"],
    url: '/bookkeeper',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/bookkeeper'
 */
Controller7d9ae9a97553f90b5982151f34a5f9d6.url = (options?: RouteQueryOptions) => {
    return Controller7d9ae9a97553f90b5982151f34a5f9d6.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/bookkeeper'
 */
Controller7d9ae9a97553f90b5982151f34a5f9d6.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller7d9ae9a97553f90b5982151f34a5f9d6.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/bookkeeper'
 */
Controller7d9ae9a97553f90b5982151f34a5f9d6.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller7d9ae9a97553f90b5982151f34a5f9d6.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/bookkeeper'
 */
    const Controller7d9ae9a97553f90b5982151f34a5f9d6Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller7d9ae9a97553f90b5982151f34a5f9d6.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/bookkeeper'
 */
        Controller7d9ae9a97553f90b5982151f34a5f9d6Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller7d9ae9a97553f90b5982151f34a5f9d6.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/bookkeeper'
 */
        Controller7d9ae9a97553f90b5982151f34a5f9d6Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller7d9ae9a97553f90b5982151f34a5f9d6.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller7d9ae9a97553f90b5982151f34a5f9d6.form = Controller7d9ae9a97553f90b5982151f34a5f9d6Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/settings/appearance'
 */
const Controllere19ee86e9cf603ce1a59a1ec5d21dec5 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'get',
})

Controllere19ee86e9cf603ce1a59a1ec5d21dec5.definition = {
    methods: ["get","head"],
    url: '/settings/appearance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/settings/appearance'
 */
Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url = (options?: RouteQueryOptions) => {
    return Controllere19ee86e9cf603ce1a59a1ec5d21dec5.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/settings/appearance'
 */
Controllere19ee86e9cf603ce1a59a1ec5d21dec5.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/settings/appearance'
 */
Controllere19ee86e9cf603ce1a59a1ec5d21dec5.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/settings/appearance'
 */
    const Controllere19ee86e9cf603ce1a59a1ec5d21dec5Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/settings/appearance'
 */
        Controllere19ee86e9cf603ce1a59a1ec5d21dec5Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/settings/appearance'
 */
        Controllere19ee86e9cf603ce1a59a1ec5d21dec5Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controllere19ee86e9cf603ce1a59a1ec5d21dec5.form = Controllere19ee86e9cf603ce1a59a1ec5d21dec5Form

/**
* Multiple routes resolve to \Inertia\Controller::Controller, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `Controller['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
const Controller = {
    '/': Controller980bb49ee7ae63891f1d891d2fbcf1c9,
    '/faq': Controller92f1f176050b935721bc0098427f55ed,
    '/our-works': Controller406184d23d716dbd5b3cb1b53a2c1750,
    '/customer': Controller6e8d88c1af9fa55d5456ce0119408fe8,
    '/customer/new-request': Controller997f8db8c1bc3eba6fdd0516c501f101,
    '/project-manager': Controllere5baf0ddea6429d5ed2876261de06f49,
    '/design-specialist': Controllera06a54fbf6b5e2042f5d214c429e5006,
    '/owner': Controllercad30db1f60378b5d578214a41b1c51b,
    '/bookkeeper': Controller7d9ae9a97553f90b5982151f34a5f9d6,
    '/settings/appearance': Controllere19ee86e9cf603ce1a59a1ec5d21dec5,
}

export default Controller
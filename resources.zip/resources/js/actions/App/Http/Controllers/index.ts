import TechnicalAdmin from './TechnicalAdmin'
import Settings from './Settings'
const Controllers = {
    TechnicalAdmin: Object.assign(TechnicalAdmin, TechnicalAdmin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers
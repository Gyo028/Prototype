import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::index
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/technical-admin/services-assets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::index
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::index
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::index
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::index
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::index
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TechnicalAdmin\ServicesAssetsController::index
 * @see app/Http/Controllers/TechnicalAdmin/ServicesAssetsController.php:21
 * @route '/technical-admin/services-assets'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const ServicesAssetsController = { index }

export default ServicesAssetsController
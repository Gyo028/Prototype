import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::index
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/technical-admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::index
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::index
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::index
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::index
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::index
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TechnicalAdmin\DashboardController::index
 * @see app/Http/Controllers/TechnicalAdmin/DashboardController.php:25
 * @route '/technical-admin'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const DashboardController = { index }

export default DashboardController
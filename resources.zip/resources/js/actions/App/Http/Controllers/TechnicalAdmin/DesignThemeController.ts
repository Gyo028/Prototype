import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::store
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:17
 * @route '/technical-admin/services-assets/themes'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/technical-admin/services-assets/themes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::store
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:17
 * @route '/technical-admin/services-assets/themes'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::store
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:17
 * @route '/technical-admin/services-assets/themes'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::store
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:17
 * @route '/technical-admin/services-assets/themes'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::store
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:17
 * @route '/technical-admin/services-assets/themes'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::update
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:24
 * @route '/technical-admin/services-assets/themes/{theme}'
 */
export const update = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/technical-admin/services-assets/themes/{theme}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::update
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:24
 * @route '/technical-admin/services-assets/themes/{theme}'
 */
update.url = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { theme: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'theme_id' in args) {
            args = { theme: args.theme_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    theme: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        theme: typeof args.theme === 'object'
                ? args.theme.theme_id
                : args.theme,
                }

    return update.definition.url
            .replace('{theme}', parsedArgs.theme.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::update
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:24
 * @route '/technical-admin/services-assets/themes/{theme}'
 */
update.patch = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::update
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:24
 * @route '/technical-admin/services-assets/themes/{theme}'
 */
    const updateForm = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::update
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:24
 * @route '/technical-admin/services-assets/themes/{theme}'
 */
        updateForm.patch = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::status
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:32
 * @route '/technical-admin/services-assets/themes/{theme}/status'
 */
export const status = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/technical-admin/services-assets/themes/{theme}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::status
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:32
 * @route '/technical-admin/services-assets/themes/{theme}/status'
 */
status.url = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { theme: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'theme_id' in args) {
            args = { theme: args.theme_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    theme: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        theme: typeof args.theme === 'object'
                ? args.theme.theme_id
                : args.theme,
                }

    return status.definition.url
            .replace('{theme}', parsedArgs.theme.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::status
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:32
 * @route '/technical-admin/services-assets/themes/{theme}/status'
 */
status.patch = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::status
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:32
 * @route '/technical-admin/services-assets/themes/{theme}/status'
 */
    const statusForm = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\DesignThemeController::status
 * @see app/Http/Controllers/TechnicalAdmin/DesignThemeController.php:32
 * @route '/technical-admin/services-assets/themes/{theme}/status'
 */
        statusForm.patch = (args: { theme: number | { theme_id: number } } | [theme: number | { theme_id: number } ] | number | { theme_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const DesignThemeController = { store, update, status }

export default DesignThemeController
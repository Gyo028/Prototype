import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::store
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:16
 * @route '/technical-admin/website-content/faqs'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/technical-admin/website-content/faqs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::store
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:16
 * @route '/technical-admin/website-content/faqs'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::store
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:16
 * @route '/technical-admin/website-content/faqs'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::store
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:16
 * @route '/technical-admin/website-content/faqs'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::store
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:16
 * @route '/technical-admin/website-content/faqs'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::update
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:31
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
export const update = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/technical-admin/website-content/faqs/{faq}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::update
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:31
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
update.url = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { faq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'content_id' in args) {
            args = { faq: args.content_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    faq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        faq: typeof args.faq === 'object'
                ? args.faq.content_id
                : args.faq,
                }

    return update.definition.url
            .replace('{faq}', parsedArgs.faq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::update
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:31
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
update.patch = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::update
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:31
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
    const updateForm = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::update
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:31
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
        updateForm.patch = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::destroy
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:46
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
export const destroy = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/technical-admin/website-content/faqs/{faq}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::destroy
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:46
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
destroy.url = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { faq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'content_id' in args) {
            args = { faq: args.content_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    faq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        faq: typeof args.faq === 'object'
                ? args.faq.content_id
                : args.faq,
                }

    return destroy.definition.url
            .replace('{faq}', parsedArgs.faq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::destroy
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:46
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
destroy.delete = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::destroy
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:46
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
    const destroyForm = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::destroy
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:46
 * @route '/technical-admin/website-content/faqs/{faq}'
 */
        destroyForm.delete = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::move
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:56
 * @route '/technical-admin/website-content/faqs/{faq}/move'
 */
export const move = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: move.url(args, options),
    method: 'patch',
})

move.definition = {
    methods: ["patch"],
    url: '/technical-admin/website-content/faqs/{faq}/move',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::move
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:56
 * @route '/technical-admin/website-content/faqs/{faq}/move'
 */
move.url = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { faq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'content_id' in args) {
            args = { faq: args.content_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    faq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        faq: typeof args.faq === 'object'
                ? args.faq.content_id
                : args.faq,
                }

    return move.definition.url
            .replace('{faq}', parsedArgs.faq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::move
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:56
 * @route '/technical-admin/website-content/faqs/{faq}/move'
 */
move.patch = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: move.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::move
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:56
 * @route '/technical-admin/website-content/faqs/{faq}/move'
 */
    const moveForm = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: move.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\FaqController::move
 * @see app/Http/Controllers/TechnicalAdmin/FaqController.php:56
 * @route '/technical-admin/website-content/faqs/{faq}/move'
 */
        moveForm.patch = (args: { faq: number | { content_id: number } } | [faq: number | { content_id: number } ] | number | { content_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: move.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    move.form = moveForm
const FaqController = { store, update, destroy, move }

export default FaqController
import DashboardController from './DashboardController'
import UserAccountController from './UserAccountController'
import WebsiteContentController from './WebsiteContentController'
import FaqController from './FaqController'
import ServicesAssetsController from './ServicesAssetsController'
import ServiceController from './ServiceController'
import DesignThemeController from './DesignThemeController'
import LayoutAssetController from './LayoutAssetController'
import EmployeeController from './EmployeeController'
const TechnicalAdmin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
UserAccountController: Object.assign(UserAccountController, UserAccountController),
WebsiteContentController: Object.assign(WebsiteContentController, WebsiteContentController),
FaqController: Object.assign(FaqController, FaqController),
ServicesAssetsController: Object.assign(ServicesAssetsController, ServicesAssetsController),
ServiceController: Object.assign(ServiceController, ServiceController),
DesignThemeController: Object.assign(DesignThemeController, DesignThemeController),
LayoutAssetController: Object.assign(LayoutAssetController, LayoutAssetController),
EmployeeController: Object.assign(EmployeeController, EmployeeController),
}

export default TechnicalAdmin
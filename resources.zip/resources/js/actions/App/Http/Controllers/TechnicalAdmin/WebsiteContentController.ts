import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::index
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/technical-admin/website-content',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::index
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::index
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::index
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::index
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::index
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::index
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:25
 * @route '/technical-admin/website-content'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateAbout
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
export const updateAbout = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateAbout.url(options),
    method: 'put',
})

updateAbout.definition = {
    methods: ["put"],
    url: '/technical-admin/website-content/about',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateAbout
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
updateAbout.url = (options?: RouteQueryOptions) => {
    return updateAbout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateAbout
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
updateAbout.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateAbout.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateAbout
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
    const updateAboutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateAbout.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateAbout
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:84
 * @route '/technical-admin/website-content/about'
 */
        updateAboutForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateAbout.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateAbout.form = updateAboutForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateServices
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
export const updateServices = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateServices.url(options),
    method: 'put',
})

updateServices.definition = {
    methods: ["put"],
    url: '/technical-admin/website-content/services',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateServices
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
updateServices.url = (options?: RouteQueryOptions) => {
    return updateServices.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateServices
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
updateServices.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateServices.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateServices
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
    const updateServicesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateServices.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateServices
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:99
 * @route '/technical-admin/website-content/services'
 */
        updateServicesForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateServices.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateServices.form = updateServicesForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateContact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
export const updateContact = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateContact.url(options),
    method: 'put',
})

updateContact.definition = {
    methods: ["put"],
    url: '/technical-admin/website-content/contact',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateContact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
updateContact.url = (options?: RouteQueryOptions) => {
    return updateContact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateContact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
updateContact.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateContact.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateContact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
    const updateContactForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateContact.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\WebsiteContentController::updateContact
 * @see app/Http/Controllers/TechnicalAdmin/WebsiteContentController.php:134
 * @route '/technical-admin/website-content/contact'
 */
        updateContactForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateContact.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateContact.form = updateContactForm
const WebsiteContentController = { index, updateAbout, updateServices, updateContact }

export default WebsiteContentController
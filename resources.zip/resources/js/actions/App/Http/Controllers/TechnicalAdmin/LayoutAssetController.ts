import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::store
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:22
 * @route '/technical-admin/services-assets/assets'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/technical-admin/services-assets/assets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::store
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:22
 * @route '/technical-admin/services-assets/assets'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::store
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:22
 * @route '/technical-admin/services-assets/assets'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::store
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:22
 * @route '/technical-admin/services-assets/assets'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::store
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:22
 * @route '/technical-admin/services-assets/assets'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::update
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:32
 * @route '/technical-admin/services-assets/assets/{asset}'
 */
export const update = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/technical-admin/services-assets/assets/{asset}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::update
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:32
 * @route '/technical-admin/services-assets/assets/{asset}'
 */
update.url = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'asset_id' in args) {
            args = { asset: args.asset_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.asset_id
                : args.asset,
                }

    return update.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::update
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:32
 * @route '/technical-admin/services-assets/assets/{asset}'
 */
update.patch = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::update
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:32
 * @route '/technical-admin/services-assets/assets/{asset}'
 */
    const updateForm = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::update
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:32
 * @route '/technical-admin/services-assets/assets/{asset}'
 */
        updateForm.patch = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::status
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:43
 * @route '/technical-admin/services-assets/assets/{asset}/status'
 */
export const status = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/technical-admin/services-assets/assets/{asset}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::status
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:43
 * @route '/technical-admin/services-assets/assets/{asset}/status'
 */
status.url = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'asset_id' in args) {
            args = { asset: args.asset_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.asset_id
                : args.asset,
                }

    return status.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::status
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:43
 * @route '/technical-admin/services-assets/assets/{asset}/status'
 */
status.patch = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::status
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:43
 * @route '/technical-admin/services-assets/assets/{asset}/status'
 */
    const statusForm = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicalAdmin\LayoutAssetController::status
 * @see app/Http/Controllers/TechnicalAdmin/LayoutAssetController.php:43
 * @route '/technical-admin/services-assets/assets/{asset}/status'
 */
        statusForm.patch = (args: { asset: number | { asset_id: number } } | [asset: number | { asset_id: number } ] | number | { asset_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const LayoutAssetController = { store, update, status }

export default LayoutAssetController